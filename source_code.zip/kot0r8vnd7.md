![](/app/user_site/src/images/kot0r8vnd7.pdf-0-0.png)

-----

-----

