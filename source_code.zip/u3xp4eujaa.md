## 5/15/2025

# **VIII. NEW BUSINESS – ACTION ITEMS**


### **2. Adoption of the 2025 Board Governance Handbook**

*Pg 12 “Questions by Board members should be communicated to the Superintendent via phone or email by 7:00 p.m. the Monday night before*

*may, encouraged to, welcomed to*
### **3. Discussion and Adoption of 2025-2028 District Board Goals and Updated Vision and** **Mission Statement**

*Champion-ship Mindset*
### **4. Discussion of Board Bylaw 9150 Student Board Members**

*Yes… AND Usher in AI to the Dias!!! What policies are out there?*
### **5. Adoption of the following Administrative Regulations, Board Bylaws, Board** **Policies, and Exhibits**


### **1. Approve Regular and Food Services Purchase Order Listings**

*PO1 -250000000018 1 WOODCRAFT RANGERS CONTRACTED SERVICES 01.3 26000.0 11100 10000 5810 0000024 244,385.55*


### **2. Approve salary expenses for the following Food Services staff**

*To provide catering services for District-sponsored events, including the LMS Youth Dinner and other events as needed, at the appropriate hou*

*Food Services Funds: 13.0-53100.0-00000-37000-2220-00X0000 13.0-53100.0-00000-37000-2210-00X0000 13.0-53100.0-00000-37000-226*


### **2. Approve service agreement (C-1138:25-26) with Aurora Vasquez** **7. Approve service agreement (C-1143:25-26) with Frances Vasquez:** **9. Approve service agreement (C-1145:25-26) with Jerome Johnson:** **14. Approve service agreement (C-1150:25-26) with Rachel Romero**

*Why are they not on the payroll? Why are we contracting out? How many times have these contracts been awarded and or extended? Do we n*
### **19. Approve service agreement (C-1164:25-26) with PowerSchool Enrollment**

*POWERCHOOL: Are the programs we’re funding making a difference academically?*

*ROI (Return On Investment) metrics? Budget, Management and Evaluation our spending*

*Implement a dashboard that flags vendors exceeding a cumulative annual threshold (e.g. $25K+) without aligned outcome metrics.*

*Require a vendor impact statement or evaluation summary for all POs over $10K.*

*Review vendors by category clusters (e.g., mental health, edutainment, legal) to detect overspending or overlap.*


-----

*Allovue takes a slightly different angle, focusing on education finance analytics and connecting dollars to results. It’s a platform that helps distri*

*Key Features: Allovue takes a slightly different angle, focusing on education finance analytics and connecting dollars to results. It’s a platform t*

*Allovue’s platform includes modules like Allocate (planning funding formulas), Budget (building school budgets with stakeholder input), and Ma*


-----

