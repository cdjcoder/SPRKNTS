5/14/2025
# **VIII. NEW BUSINESS – ACTION ITEMS**
## **A. Superintendent's Office**
### **2. Adoption of the 2025 Board Governance Handbook**

*Pg 12 “Questions by Board members should be communicated to the Superintendent*
*via phone or email by 7:00 p.m. the Monday night before a Board meeting to allow for*
*complete answers. ”*

*may, encouraged to, welcomed to*
### **3. Discussion and Adoption of 2025-2028 District Board Goals and Updated Vision and Mission**

*Champion-ship Mindset*
### **4. Discussion of Board Bylaw 9150 Student Board Members**

*Yes… AND Usher in AI to the Dias!!! What policies are out there?*
### **5. Adoption of the following Administrative Regulations, Board Bylaws, Board Policies, and Exh**

*Bylaw 9224: Oath Or Affirmation - Any updates?*
## **B. Business Office**
### **1. Approve Regular and Food Services Purchase Order Listings**

*PO1 -250000000018 1 WOODCRAFT RANGERS CONTRACTED SERVICES 01.3*

*26000.0 11100 10000 5810 0000024 244,385.55*

*No*
## **C. Food Service Items**
### **2. Approve salary expenses for the following Food Services staff**

*To provide catering services for District-sponsored events, including the LMS Youth*
*Dinner and other events as needed, at the appropriate hourly pay rate, during the*
*2025–2026 school year. Cafeteria Managers Cafeteria Helpers Cafeteria Substitute*
*Helpers Not to exceed an estimated cost of $45,000*

*Food Services Funds: 13.0-53100.0-00000-37000-2220-00X0000*

*13.0-53100.0-00000-37000-2210-00X0000 13.0-53100.0-00000-37000-2260-0000016*

*Cater for board meetings and retreats*
## **G. Lennox Expanded Learning Program (LEAP) Items**


-----

### **2. Approve service agreement (C-1138:25-26) with Aurora Vasquez** **7. Approve service agreement (C-1143:25-26) with Frances Vasquez:** **9. Approve service agreement (C-1145:25-26) with Jerome Johnson:** **14. Approve service agreement (C-1150:25-26) with Rachel Romero**

*Why are they not on the payroll? Why are we contracting out? How many times have*
*these contracts been awarded and or extended? Do we not have staff capable of these*
*assignments already? If not, why not create a permanent position?*
### **19. Approve service agreement (C-1164:25-26) with PowerSchool Enrollment**

*POWERCHOOL: Are the programs we’re funding making a difference academically?*

*ROI (Return On Investment) metrics? Budget, Management and Evaluation our*
*spending*

*Implement a dashboard that flags vendors exceeding a cumulative annual threshold*
*(e.g. $25K+) without aligned outcome metrics.*

*Require a vendor impact statement or evaluation summary for all POs over $10K.*

*Review vendors by category clusters (e.g., mental health, edutainment, legal) to detect*
*overspending or overlap.*

*Allovue takes a slightly different angle, focusing on education finance analytics and*
*connecting dollars to results. It’s a platform that helps districts budget, manage*
*spending, and evaluate the impact of investments*

*Key Features: Allovue takes a slightly different angle, focusing on education finance*
*analytics and connecting dollars to results. It’s a platform that helps districts budget,*
*manage spending, and evaluate the impact of investments. Allovue provides tools for*
*priority-based budgeting (aligning each dollar in the budget to district strategic priorities)*
*and then tracking spending vs. budget throughout the year. The standout feature for*
*program accountability is that Allovue can integrate financial data with student outcome*
*data to assess if resources are yielding the intended outcomes kaporcapital.com. For*
*example, a district might tag all expenditures for a literacy intervention program and*
*then use Allovue to visualize reading score trends alongside those expenditures. This*
*answers the question: Are the programs we’re funding making a difference*
*academically?*

*Allovue’s platform includes modules like Allocate (planning funding formulas), Budget*
*(building school budgets with stakeholder input), and Manage (tracking actual*
*spending). Through these, district leaders can set up accountability metrics for each*
*funding item – e.g. an elementary math coaching program’s success*

Page 1


-----

