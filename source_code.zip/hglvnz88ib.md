5/14/2025
# **VIII. NEW BUSINESS – ACTION ITEMS**
## **A. Superintendent's Office**

**2** **Adoption of the 2025 Board Governance Handbook**

*Superintendent via phone or email by 7:00 p.m. the Monday night before a*
*Board meeting to allow for complete answers. ”*

**3** **Discussion and Adoption of 2025-2028 District Board Goals and Updated**
**Vision and Mission Statement**

**4** **Discussion of Board Bylaw 9150 Student Board Members**

**5** **Adoption of the following Administrative Regulations, Board Bylaws,**
**Board Policies, and Exhibits**
## **B. Business Office**

**1** **Approve Regular and Food Services Purchase Order Listings**

*SERVICES 01.3 26000.0 11100 10000 5810 0000024 244,385.55*
## **C. Food Service Items**


Page 1


-----

**2** **Approve salary expenses for the following Food Services staff**

*LMS Youth Dinner and other events as needed, at the appropriate hourly*
*pay rate, during the 2025–2026 school year. Cafeteria Managers Cafeteria*
*Helpers Cafeteria Substitute Helpers Not to exceed an estimated cost of*
*$45,000*

*13.0-53100.0-00000-37000-2260-0000016*
## **G. Lennox Expanded Learning Program (LEAP) Items**

**2** **Approve service agreement (C-1138:25-26) with Aurora Vasquez**

**7** **Approve service agreement (C-1143:25-26) with Frances Vasquez:**

**9** **Approve service agreement (C-1145:25-26) with Jerome Johnson:**

**14** **Approve service agreement (C-1150:25-26) with Rachel Romero**

*have staff capable of these assignments already? If not, why not create a*
*permanent position?*

**19** **Approve service agreement (C-1164:25-26) with PowerSchool Enrollment**

*academically?*

*Evaluation our spending*

*threshold (e.g. $25K+) without aligned outcome metrics.*


Page 2


-----

*legal) to detect overspending or overlap.*

*analytics and connecting dollars to results. It’s a platform that helps*
*districts budget, manage spending, and evaluate the impact of*
*investments*

*education finance analytics and connecting dollars to results. It’s a*
*platform that helps districts budget, manage spending, and evaluate the*
*impact of investments. Allovue provides tools for priority-based budgeting*
*(aligning each dollar in the budget to district strategic priorities) and then*
*tracking spending vs. budget throughout the year. The standout feature for*
*program accountability is that Allovue can integrate financial data with*
*student outcome data to assess if resources are yielding the intended*
*outcomes kaporcapital.com. For example, a district might tag all*
*expenditures for a literacy intervention program and then use Allovue to*
*visualize reading score trends alongside those expenditures. This answers*
*the question: Are the programs we’re funding making a difference*
*academically?*

*formulas), Budget (building school budgets with stakeholder input), and*
*Manage (tracking actual spending). Through these, district leaders can set*
*up accountability metrics for each funding item – e.g. an elementary math*
*coaching program’s success*


Page 3


-----

